#include<stdio.h>
#include<string.h>
int main()
{
    char * p;
    p="hellow world";
    return p;
}